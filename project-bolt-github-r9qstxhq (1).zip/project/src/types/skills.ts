export interface Skill {
  title: string;
  items: string[];
}