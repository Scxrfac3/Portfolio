export interface Experience {
  title: string;
  company: string;
  duration: string;
  achievements: string[];
}